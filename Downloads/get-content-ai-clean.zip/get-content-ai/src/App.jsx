export default function App() {
  return <h1>Hello from GetContentAI 🎉</h1>;
}
