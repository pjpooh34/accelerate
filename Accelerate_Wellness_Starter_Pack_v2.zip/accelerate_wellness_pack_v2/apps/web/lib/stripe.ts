import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing STRIPE_SECRET_KEY");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

export const priceMap: Record<string, string> = {
  diy: process.env.STRIPE_PRICE_DIY || "",
  core: process.env.STRIPE_PRICE_CORE || "",
  pro: process.env.STRIPE_PRICE_PRO || "",
};
