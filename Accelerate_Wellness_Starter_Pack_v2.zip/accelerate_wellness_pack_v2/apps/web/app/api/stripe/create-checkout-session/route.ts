import { NextRequest, NextResponse } from "next/server";
import { stripe, priceMap } from "@/apps/web/lib/stripe";

export async function POST(req: NextRequest) {
  try {
    const { plan = "core", orgId } = await req.json();
    const price = priceMap[plan];
    if (!price) return NextResponse.json({ ok: false, error: "Invalid plan" }, { status: 400 });

    const success = `${process.env.NEXT_PUBLIC_SITE_URL || ""}/onboarding?session_id={CHECKOUT_SESSION_ID}`;
    const cancel = `${process.env.NEXT_PUBLIC_SITE_URL || ""}/pricing`;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price, quantity: 1 }],
      success_url: success,
      cancel_url: cancel,
      metadata: orgId ? { orgId } : undefined
    });

    return NextResponse.json({ ok: true, url: session.url });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
