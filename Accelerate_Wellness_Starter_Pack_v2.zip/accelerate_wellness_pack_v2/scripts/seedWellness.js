// Minimal JS seed script if TS toolchain isn't available in CI
const { PrismaClient } = require("@prisma/client");
const fs = require("fs");
const prisma = new PrismaClient();

async function main(){
  const raw = fs.readFileSync("packages/templates/verticals/wellness_full.json", "utf-8");
  const tpl = JSON.parse(raw);
  const items = [
    ...tpl.caption_templates.map((t)=>({vertical: tpl.vertical, channel: t.channel, kind: "caption", body: t.body, weight: 1})),
    ...tpl.reel_templates.map((t)=>({vertical: tpl.vertical, channel: "tiktok", kind: "reel_script", body: JSON.stringify(t.body), weight: 1})),
    ...tpl.gbp_templates.map((t)=>({vertical: tpl.vertical, channel: "gbp", kind: "gbp", body: t.body, weight: 1})),
    ...tpl.offer_templates.map((t)=>({vertical: tpl.vertical, channel: "facebook", kind: "offer", body: t.body, weight: 1}))
  ];
  for (const it of items) { await prisma.template.create({ data: it }); }
  console.log(`Seeded ${items.length} wellness templates`);
}

main().finally(()=>prisma.$disconnect());
