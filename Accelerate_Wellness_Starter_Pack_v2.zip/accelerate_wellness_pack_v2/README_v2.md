# Added in v2

- Stripe checkout & webhook API routes.
- GitHub Actions workflow to run Prisma migrate + seed on push to main (uses `secrets.DATABASE_URL`).
- `vercel.json` with cron examples.
- JS seed script for CI without ts-node.

## Env vars to set (Vercel + GH Secrets)
DATABASE_URL
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
STRIPE_PRICE_DIY
STRIPE_PRICE_CORE
STRIPE_PRICE_PRO
NEXT_PUBLIC_SITE_URL
